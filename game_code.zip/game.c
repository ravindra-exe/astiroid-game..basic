#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define H 10
#define W 20
#define MAX_OBS 200

typedef struct {
    int cx;
    int cy;
} Block;

int main(void) {
    int shipRow = H / 2;
    int points = 0;
    int best = 0;
    int life = 3;
    int level = 1;
    int tick = 0;

    Block obs[MAX_OBS];
    int obsCount = 0;

    char key;
    int i, r, c;

    srand((unsigned)time(NULL));

    printf("Choose Difficulty:\\n1. Easy\\n2. Medium\\n3. Hard\\nEnter: ");
    scanf("%d", &level);
    if (level < 1 || level > 3) {
        level = 1;
    }

    while (1) {

        if ((rand() % (4 - level)) == 0 && obsCount < MAX_OBS) {
            obs[obsCount].cx = W - 1;
            obs[obsCount].cy = rand() % H;
            obsCount++;
        }

        char board[H][W];
        for (r = 0; r < H; r++) {
            for (c = 0; c < W; c++) {
                board[r][c] = ' ';
            }
        }

        board[shipRow][2] = '>';

        for (i = 0; i < obsCount; i++) {
            obs[i].cx--;
        }

        int newCount = 0;
        for (i = 0; i < obsCount; i++) {
            if (obs[i].cx >= 0) {
                obs[newCount] = obs[i];
                newCount++;
            }
        }
        obsCount = newCount;

        for (i = 0; i < obsCount; i++) {
            if (obs[i].cx >= 0 && obs[i].cx < W &&
                obs[i].cy >= 0 && obs[i].cy < H) {
                board[obs[i].cy][obs[i].cx] = '*';
            }
        }

        for (i = 0; i < obsCount; i++) {
            if (obs[i].cx == 2 && obs[i].cy == shipRow) {

                life--;
                if (life == 0) {
                    if (points > best) best = points;
                    printf("\\nGAME OVER!\\n");
                    printf("Final Score: %d\\nHigh Score: %d\\n", points, best);
                    return 0;
                }

                printf("\\nCrash! Lives left: %d\\n", life);
                points -= 5;
                if (points < 0) points = 0;

                obsCount = 0;
                continue;
            }
        }

        if (points > best) best = points;

        printf("\\nScore: %d   High Score: %d   Lives: %d\\n",
               points, best, life);

        for (r = 0; r < H; r++) {
            printf("|");
            for (c = 0; c < W; c++) {
                putchar(board[r][c]);
            }
            printf("|\\n");
        }

        printf("Move (U/D/S): ");
        if (scanf(" %c", &key) != 1) break;

        if (key == 'U' || key == 'u') {
            if (shipRow > 0) shipRow--;
        } else if (key == 'D' || key == 'd') {
            if (shipRow < H - 1) shipRow++;
        }

        points++;
        tick++;
    }

    return 0;
}
